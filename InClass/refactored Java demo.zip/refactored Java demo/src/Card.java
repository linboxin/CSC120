/**
 * models a playing card
 */
public class Card {

    // constants use the keyword 'final'
    private final int DEFAULT_RANK = 14;
    private final String DEFAULT_SUIT = "Hearts";

    private final int ACE = 14;
    private final int KING = 13;
    private final int QUEEN = 12;
    private final int JACK = 11;

    private final int RANK = 0;
    private final int SUIT = 1;

    // DECLARE instance variables

//    private int rank;    // 2-14
//    private String suit; // "Clubs", etc.
    private int[] card_info;

    /**
     * non default-constructor == constructor with params
     *
     * @param newRank int in range 2-14
     * @param newSuit String spelled out like "Clubs"
     */
    public Card(int newRank, String newSuit) {
        card_info = new int[2];
        card_info[RANK] = newRank;
//        card_info[SUIT] =
    }

    /**
     * default constructor == constructor with no parameters
     */
    public Card() {
        this.rank = DEFAULT_RANK;
        this.suit = DEFAULT_SUIT;
    }

    /**
     * non-default constructor
     *
     * @param newSuit suit spelled out like "Clubs"
     */
    public Card(String newSuit) {
        this.rank = DEFAULT_RANK;
        this.suit = newSuit;
    }

    /**
     * getter for the rank
     *
     * @return int from 2-14
     */
    public int getRank() {
        return card_info[RANK];
    }

    /**
     * getter for suit
     *
     * @return String denoting full suit like "Spades"
     */
    public String getSuit() {
        return suit;
    }

    /**
     * return this Card as a printable string
     *
     * @return card's full name like "Ace of Hearts"
     */
    public String toString() {
        int rank = this.getRank();
        String rankToPrint;
        if (rank == ACE) {
            rankToPrint = "Ace";
        }
        else if (rank == KING) {
            rankToPrint = "King";
        }
        else if (rank == QUEEN) {
            rankToPrint = "Queen";
        }
        else if (rank == JACK) {
            rankToPrint = "Jack";
        }
        else {
            rankToPrint = "" + rank;
        }
        return rankToPrint + " of " + getSuit();
    }
}
