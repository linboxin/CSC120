SUITS = ['Clubs', 'Diamonds', 'Hearts', 'Spades']
MIN_RANK = 1
MAX_RANK = 13