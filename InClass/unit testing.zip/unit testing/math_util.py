def total(x,y):
    """returns sum of x and y"""
    return x+y

def product(x,y):
    """returns product of x and y"""
    return x*y