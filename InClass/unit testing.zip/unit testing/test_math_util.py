"""testing suite for math_util module"""

from math_util import *
from testing import *

def test_total():
    pass


def test_product():
    pass

"""
Individual unit tests start here
"""



"""
Individual unit tests end here
"""
if __name__=="__main__":
    test_total()
    test_product()
