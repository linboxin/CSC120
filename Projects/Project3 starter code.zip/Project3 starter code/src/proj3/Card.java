package proj3; // do not erase. Gradescope expects this.

public class Card {


}
